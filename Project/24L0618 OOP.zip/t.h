#pragma once
#include "tetromino.h"

class TShape : public Tetromino {
public:
    TShape();
    virtual void rotate() override;
    virtual void setInitialPosition() override;
};