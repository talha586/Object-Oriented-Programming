#include "game.h"
#include<cstring>

Game::Game() : window(sf::VideoMode(SCREEN_WIDTH, SCREEN_HEIGHT), "Tetris Game") 
{
    // Load textures
    tilesTexture.loadFromFile("tiles.png");
    backgroundTexture.loadFromFile("background.png");
    frameTexture.loadFromFile("frame.png");

    // Set up sprites
    background.setTexture(backgroundTexture);
    tile.setTexture(tilesTexture);
    frame.setTexture(frameTexture);

    // Load font
    font.loadFromFile("Voltaire-Frangela.ttf");

    // Set up text
    scoreText.setFont(font);
    scoreText.setCharacterSize(20);
    scoreText.setFillColor(sf::Color::Black);
    scoreText.setPosition(20, 420);
    scoreText.setString("SCORE: 0");

    levelText.setFont(font);
    levelText.setCharacterSize(20);
    levelText.setFillColor(sf::Color::Black);
    levelText.setPosition(200, 420);
    levelText.setString("LEVEL: 1");

    instructionText.setFont(font);
    instructionText.setCharacterSize(20);
    instructionText.setFillColor(sf::Color::White);
    instructionText.setPosition(20, 140);
    instructionText.setString("INSTRUCTIONS!\n\nUse UP Key to Rotate\nUse RIGHT Key to Move right\n""Use LEFT Key to Move left\nUse DOWN key to move fast\n""Press SPACE to Start");

    gameOverText.setFont(font);
    gameOverText.setCharacterSize(20);
    gameOverText.setFillColor(sf::Color::White);
    gameOverText.setPosition(20, 140);
    gameOverText.setString("GAME OVER!\n\nPress SPACE to Restart");

    // Load music
    backgroundMusic.openFromFile("song.mp3");
    backgroundMusic.setLoop(true);
    backgroundMusic.setVolume(20);

    gameOverMusic.openFromFile("gameover.mp3");
    gameOverMusic.setVolume(20);

    // Initialize game
    createtetromino();
}

void Game::run() 
{
    backgroundMusic.play();

    while (window.isOpen()) {
        processEvents();

        float deltaTime = clock.restart().asSeconds();
        timer += deltaTime;

        if (gameStarted && !gameEnded) 
        {
            update(deltaTime);
        }

        render();
    }
}

void Game::processEvents() {
    sf::Event event;
    while (window.pollEvent(event)) {
        if (event.type == sf::Event::Closed) {
            window.close();
        }

        if (event.type == sf::Event::KeyPressed) {
            if (event.key.code == sf::Keyboard::Escape) {
                window.close();
            }

            if (!gameStarted && event.key.code == sf::Keyboard::Space) {
                gameStarted = true;
            }

            if (gameEnded && event.key.code == sf::Keyboard::Space) {
                resetGame();
            }

            if (gameStarted && !gameEnded) {
                if (event.key.code == sf::Keyboard::Up) {
                    rotateTetromino();
                }
                else if (event.key.code == sf::Keyboard::Right) {
                    movement(1, 0);
                }
                else if (event.key.code == sf::Keyboard::Left) {
                    movement(-1, 0);
                }
                else if (event.key.code == sf::Keyboard::Down) {
                    delay = 0.05f;
                }
            }
        }
    }
}

void Game::update(float deltaTime) {
    if (timer > delay) {
        movement(0, 1);
        timer = 0;
    }

    // Reset delay after fast drop
    if (delay < 0.3f) {
        delay = 0.3f;
    }
}

void Game::render() {
    window.clear(sf::Color::Black);

    if (!gameStarted) 
    {
        renderInstructions();
    }
    else if (gameEnded) 
    {
        renderGameOver();
    }
    else 
    {
        renderGame();
    }

    window.display();
}

void Game::renderGame() 
{
    window.draw(background);

    // Draw the field
    for (int i = 0; i < FIELD_HEIGHT; i++) {
        for (int j = 0; j < FIELD_WIDTH; j++) {
            if (field[i][j] == 0) continue;

            tile.setTextureRect(sf::IntRect(field[i][j] * BLOCK_SIZE, 0, BLOCK_SIZE, BLOCK_SIZE));
            tile.setPosition(j * BLOCK_SIZE, i * BLOCK_SIZE);
            tile.move(28, 31); // Offset for the frame
            window.draw(tile);
        }
    }

    // Draw the current tetromino
    const Point* blocks = currentTetromino->getBlocks();
    int color = currentTetromino->getColor();

    for (int i = 0; i < 4; i++) {
        tile.setTextureRect(sf::IntRect(color * BLOCK_SIZE, 0, BLOCK_SIZE, BLOCK_SIZE));
        tile.setPosition(blocks[i].x * BLOCK_SIZE, blocks[i].y * BLOCK_SIZE);
        tile.move(28, 31); // Offset for the frame
        window.draw(tile);
    }

    window.draw(frame);
    window.draw(scoreText);
    window.draw(levelText);
}

void Game::renderInstructions() {
    window.draw(instructionText);
}

void Game::renderGameOver() {
    window.draw(gameOverText);
}

void Game::createtetromino() 
{
    int number = rand()% 7;
    switch (number) 
    {
    case 0: currentTetromino = std::make_unique<IShape>(); break;
    case 1: currentTetromino = std::make_unique<JShape>(); break;
    case 2: currentTetromino = std::make_unique<LShape>(); break;
    case 3: currentTetromino = std::make_unique<OShape>(); break;
    case 4: currentTetromino = std::make_unique<SShape>(); break;
    case 5: currentTetromino = std::make_unique<TShape>(); break;
    case 6: currentTetromino = std::make_unique<ZShape>(); break;
    }
}

bool Game::check() const 
{
    const Point* blocks = currentTetromino->getBlocks();

    for (int i = 0; i < 4; i++) 
    {
        int x = blocks[i].x;
        int y = blocks[i].y;

        if (x < 0 || x >= FIELD_WIDTH || y >= FIELD_HEIGHT) {
            return false;
        }

        if (y >= 0 && field[y][x] != 0) {
            return false;
        }
    }

    return true;
}

void Game::movement(int dx, int dy) 
{
    currentTetromino->move(dx, dy);

    if (!check()) 
    {
        currentTetromino->move(-dx, -dy);

        if (dy > 0)
        {                     // Moving down
            placeTetromino();
        }
    }
}

void Game::rotateTetromino() {
    currentTetromino->rotate();

    if (!check()) {
        // Rotate back if collision occurs
        for (int i = 0; i < 3; i++) {
            currentTetromino->rotate();
        }
    }
}

void Game::placeTetromino()
{
    const Point* blocks = currentTetromino->getBlocks();
    int color = currentTetromino->getColor();

    for (int i = 0; i < 4; i++) {
        int x = blocks[i].x;
        int y = blocks[i].y;

        if (y <= 0) {
            gameEnded = true;
            backgroundMusic.stop();
            gameOverMusic.play();

            // Build game over string without sstream
            std::string gameOverString = "GAME OVER!\n\nSCORE: " +
                std::to_string(score) +
                "\nLEVEL: " +
                std::to_string(level) +
                "\n\nPress SPACE to Restart";
            gameOverText.setString(gameOverString);
            return;
        }

        field[y][x] = color;
    }

    int linesCleared = clearLines();
    if (linesCleared > 0) {
        score += linesCleared * 100;

        // Update score text without sstream
        scoreText.setString("SCORE: " + std::to_string(score));

        int newLevel = score / 500 + 1;

        if (newLevel > level) {
            level = newLevel;

            // Update level text without sstream
            levelText.setString("LEVEL: " + std::to_string(level));

            // Increase speed with level
            delay = std::max(0.05f, 0.3f - (level - 1) * 0.05f);
        }
    }
    createtetromino();
}

int Game::clearLines() {
    int linesCleared = 0;

    for (int y = FIELD_HEIGHT - 1; y >= 0; y--) {
        bool lineComplete = true;

        for (int x = 0; x < FIELD_WIDTH; x++) {
            if (field[y][x] == 0) {
                lineComplete = false;
                break;
            }
        }

        if (lineComplete) {
            linesCleared++;

            // Move all lines above down
            for (int y2 = y; y2 > 0; y2--) {
                for (int x = 0; x < FIELD_WIDTH; x++) {
                    field[y2][x] = field[y2 - 1][x];
                }
            }

            // Clear top line
            for (int x = 0; x < FIELD_WIDTH; x++) {
                field[0][x] = 0;
            }

            y++; // Check the same row again
        }
    }

    return linesCleared;
}

void Game::resetGame() {
    // Clear the field
    for (int y = 0; y < FIELD_HEIGHT; y++) {
        for (int x = 0; x < FIELD_WIDTH; x++) {
            field[y][x] = 0;
        }
    }

    // Reset game state
    score = 0;
    level = 1;
    delay = 0.3f;
    timer = 0;
    gameEnded = false;

    // Reset UI
    scoreText.setString("SCORE: 0");
    levelText.setString("LEVEL: 1");

    // Create new tetromino
    createtetromino();

    // Restart music
    backgroundMusic.play();
}