#pragma once
#include "tetromino.h"

class LShape : public Tetromino 
{
public:
    LShape();
    virtual void rotate() override;
    virtual void setInitialPosition() override;
};