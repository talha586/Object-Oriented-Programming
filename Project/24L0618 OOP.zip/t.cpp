#include"t.h"
TShape::TShape() {
    colorNum = 6; // Purple
    rotationState = 0;
    setInitialPosition();
}

void TShape::rotate(){
    Point center = blocks[1];
    Point newBlocks[4];

    switch (rotationState) {
    case 0:
        newBlocks[0] = { center.x, center.y - 1 };
        newBlocks[1] = { center.x, center.y };
        newBlocks[2] = { center.x, center.y + 1 };
        newBlocks[3] = { center.x - 1, center.y };
        break;
    case 1:
        newBlocks[0] = { center.x - 1, center.y };
        newBlocks[1] = { center.x, center.y };
        newBlocks[2] = { center.x + 1, center.y };
        newBlocks[3] = { center.x, center.y - 1 };
        break;
    case 2:
        newBlocks[0] = { center.x, center.y - 1 };
        newBlocks[1] = { center.x, center.y };
        newBlocks[2] = { center.x, center.y + 1 };
        newBlocks[3] = { center.x + 1, center.y };
        break;
    case 3:
        newBlocks[0] = { center.x - 1, center.y };
        newBlocks[1] = { center.x, center.y };
        newBlocks[2] = { center.x + 1, center.y };
        newBlocks[3] = { center.x, center.y + 1 };
        break;
    }

    for (int i = 0; i < 4; i++) {
        blocks[i] = newBlocks[i];
    }

    rotationState = (rotationState + 1) % 4;
}

void TShape::setInitialPosition()
{
    blocks[0] = { 3, 1 };
    blocks[1] = { 4, 1 };
    blocks[2] = { 5, 1 };
    blocks[3] = { 4, 0 };
}