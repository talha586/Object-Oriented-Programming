#include"s.h"

SShape::SShape() {
    colorNum = 5; // Green
    rotationState = 0;
    setInitialPosition();
}

void SShape::rotate()
{
    Point center = blocks[1];
    Point newBlocks[4];

    if (rotationState == 0) {
        // Horizontal to vertical
        newBlocks[0] = { center.x, center.y - 1 };
        newBlocks[1] = { center.x, center.y };
        newBlocks[2] = { center.x + 1, center.y };
        newBlocks[3] = { center.x + 1, center.y + 1 };
    }
    else {
        // Vertical to horizontal
        newBlocks[0] = { center.x - 1, center.y + 1 };
        newBlocks[1] = { center.x, center.y + 1 };
        newBlocks[2] = { center.x, center.y };
        newBlocks[3] = { center.x + 1, center.y };
    }

    for (int i = 0; i < 4; i++) {
        blocks[i] = newBlocks[i];
    }

    rotationState = (rotationState + 1) % 2;
}

void SShape:: setInitialPosition(){
    blocks[0] = { 4, 1 };
    blocks[1] = { 5, 1 };
    blocks[2] = { 5, 0 };
    blocks[3] = { 6, 0 };
}