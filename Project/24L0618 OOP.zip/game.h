
#pragma once
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <random>
#include "tetromino.h"
#include "i.h"
#include "j.h"
#include "l.h"
#include "o.h"
#include "s.h"
#include "t.h"
#include "z.h"

const int FIELD_WIDTH = 10;
const int FIELD_HEIGHT = 20;
const int BLOCK_SIZE = 18;
const int SCREEN_WIDTH = 320;
const int SCREEN_HEIGHT = 480;

class Game 
{
private:
    sf::RenderWindow window;

    // Graphics
    sf::Texture tilesTexture;
    sf::Texture backgroundTexture;
    sf::Texture frameTexture;
    sf::Sprite background;
    sf::Sprite tile;
    sf::Sprite frame;

    // Text
    sf::Font font;
    sf::Text scoreText;
    sf::Text levelText;
    sf::Text instructionText;
    sf::Text gameOverText;

    // Audio
    sf::Music backgroundMusic;
    sf::Music gameOverMusic;

    // Game state
    sf::Clock clock;
    int score = 0;
    int level = 1;
    float delay = 0.3f;
    float timer = 0;
    bool gameStarted = false;
    bool gameEnded = false;

    // Game elements
    int field[FIELD_HEIGHT][FIELD_WIDTH] = { 0 };
    std::unique_ptr<Tetromino> currentTetromino;

    // Private methods
    void createtetromino();
    bool check() const;
    int clearLines();
    void resetGame();
    // Input handling
    void processEvents();

    // Rendering
    void render();
    void renderGame();
    void renderInstructions();
    void renderGameOver();

    // Game logic
    void update(float deltaTime);
    void movement(int dx, int dy);
    void rotateTetromino();
    void placeTetromino();
public:
    Game();
    void run();
};
