#pragma once
#include "tetromino.h"

class SShape : public Tetromino
{
public:
    SShape();
    virtual void rotate() override;
    virtual void setInitialPosition() override;
};