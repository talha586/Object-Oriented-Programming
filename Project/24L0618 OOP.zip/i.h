#pragma once
#include "tetromino.h"

class IShape : public Tetromino 
{
public:
    IShape();
   virtual void rotate() override;
   virtual  void setInitialPosition() override;
};