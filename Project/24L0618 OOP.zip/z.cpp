#include"z.h"
ZShape::ZShape() {
    colorNum = 7; // Red
    rotationState = 0;
    setInitialPosition();
}

void ZShape:: rotate()
{
    Point center = blocks[1];
    Point newBlocks[4];

    if (rotationState == 0) {
        // Horizontal to vertical
        newBlocks[0] = { center.x, center.y - 1 };
        newBlocks[1] = { center.x, center.y };
        newBlocks[2] = { center.x - 1, center.y };
        newBlocks[3] = { center.x - 1, center.y + 1 };
    }
    else {
        // Vertical to horizontal
        newBlocks[0] = { center.x - 1, center.y };
        newBlocks[1] = { center.x, center.y };
        newBlocks[2] = { center.x, center.y + 1 };
        newBlocks[3] = { center.x + 1, center.y + 1 };
    }

    for (int i = 0; i < 4; i++) {
        blocks[i] = newBlocks[i];
    }

    rotationState = (rotationState + 1) % 2;
}

void ZShape:: setInitialPosition()
{
    blocks[0] = { 4, 0 };
    blocks[1] = { 5, 0 };
    blocks[2] = { 5, 1 };
    blocks[3] = { 6, 1 };
}