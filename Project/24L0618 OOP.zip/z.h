#pragma once
#include "tetromino.h"

class ZShape : public Tetromino {
public:
    ZShape();
    virtual void rotate() override;
    virtual void setInitialPosition() override;
};