#pragma once
#include "tetromino.h"

class OShape : public Tetromino {
public:
    OShape();
    virtual void rotate() override;
    virtual  void setInitialPosition() override;
};