#include"i.h"
IShape::IShape() {
    colorNum = 1; // Cyan
    rotationState = 0;
    setInitialPosition();
}

void IShape::rotate() 
{
    Point center = blocks[1];
    Point newBlocks[4];

    if (rotationState == 0) {
        // Vertical to horizontal
        newBlocks[0] = { center.x - 1, center.y };
        newBlocks[1] = { center.x, center.y };
        newBlocks[2] = { center.x + 1, center.y };
        newBlocks[3] = { center.x + 2, center.y };
    }
    else {
        // Horizontal to vertical
        newBlocks[0] = { center.x, center.y - 1 };
        newBlocks[1] = { center.x, center.y };
        newBlocks[2] = { center.x, center.y + 1 };
        newBlocks[3] = { center.x, center.y + 2 };
    }

    for (int i = 0; i < 4; i++) {
        blocks[i] = newBlocks[i];
    }

    rotationState = (rotationState + 1) % 2;
}

void IShape::setInitialPosition() 
{
    blocks[0] = { 3, 0 };
    blocks[1] = { 3, 1 };
    blocks[2] = { 3, 2 };
    blocks[3] = { 3, 3 };
}