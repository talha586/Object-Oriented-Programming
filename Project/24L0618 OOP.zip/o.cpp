#include"o.h"
OShape::OShape() {
    colorNum = 4; // Yellow
    rotationState = 0;
    setInitialPosition();
}

void OShape::rotate() 
{
    // O-shape doesn't rotate
}

void OShape::setInitialPosition()
{
    blocks[0] = { 4, 0 };
    blocks[1] = { 5, 0 };
    blocks[2] = { 4, 1 };
    blocks[3] = { 5, 1 };
}