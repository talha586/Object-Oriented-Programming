#pragma once
#include <SFML/Graphics.hpp>

struct Point 
{
    int x;
    int y;
};

class Tetromino 
{
protected:
    Point blocks[4]; // Current positions of the 4 blocks
    int colorNum;
    int rotationState;

public:
    virtual ~Tetromino() = default;

    const Point* getBlocks() const
    { 
        return blocks;
    }

    int getColor() const 
    {
        return colorNum; 
    }

    virtual void rotate() = 0;
    virtual void setInitialPosition() = 0;

    void move(int dx, int dy) 
    {
        for (int i = 0; i < 4; i++) 
        {
            blocks[i].x += dx;
            blocks[i].y += dy;
        }
    }

    void setPosition(int x, int y) 
    {
        for (int i = 0; i < 4; i++) 
        {
            blocks[i].x += x;
            blocks[i].y += y;
        }
    }
};