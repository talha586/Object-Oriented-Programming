#pragma once
#include "tetromino.h"

class JShape : public Tetromino {
public:
    JShape();
   virtual void rotate() override;
    virtual void setInitialPosition() override;
};